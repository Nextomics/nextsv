#!/bin/bash

bash test/test_1.sh
bash test/test_2.sh
bash test/test_3.sh
bash test/test_4.sh
